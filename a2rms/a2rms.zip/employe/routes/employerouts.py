from fastapi import APIRouter
from fastapi.responses import JSONResponse
from employe.models.employemodel import Employeetablecreate, EmployeTable
import json
router = APIRouter()

@router.post("/api/v1/addstaff")
async def addStaff(body: Employeetablecreate):
    data = EmployeTable(**body.dict())
    data.save()
    tojson = data.to_json()
    fromjson = json.loads(tojson)
    return {
        "message":"Staff Added",
        "data": fromjson,
        "status":True
    }
    