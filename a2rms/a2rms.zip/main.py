from fastapi import FastAPI, Form
from mongoengine import connect
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.requests import Request
app = FastAPI()
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

@app.post("/login")
async def loginpage( username: str = Form(...), password: str = Form(...)):
    if username == "admin":
        if password == "admin": 
            return RedirectResponse(url="/home")

@app.get("/", response_class=HTMLResponse)
async def get_login_form(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.post("/home", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.get("/perticulerstaff", response_class=HTMLResponse)
async def perticulerUser(request: Request):
    return templates.TemplateResponse("userdetail.html", {"request": request})

@app.get("/addstaff", response_class=HTMLResponse)
async def perticulerUser(request: Request):
    return templates.TemplateResponse("info.html", {"request": request})
